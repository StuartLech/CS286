Stuart Lech 800728996 Slech@siue.edu
Jalen Quinn 800726251 jalquim@siue.edu
Mohammad Khan 800657296 mohkhan@siue.edu

