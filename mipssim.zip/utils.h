#pragma once
#include <string>

std::string get_val_bits(int val, int off, int nbits);
int expand_sign(int val, int nbits);